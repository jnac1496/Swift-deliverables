import UIKit

var songname : String = "Song name: Say you won't let go "
var songalbum : String = "Album: Back from the edge "
var artist : String = "Artist: James Arthur "
var genre : String = "Genre: Pop "
var yearreleased : Int = 2016
var duration : Double = 3.5
var label : String = "Label: Columbia"
var producer : String = "Producers: Alex Beitzke & Bradley Spence"


print(songname) ; print(songalbum) ; print(artist) ; print(genre) ; print("Year released: " + String(yearreleased)); print("Duration: " + String(duration)) ; print(label) ; print(producer)
